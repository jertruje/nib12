/**
 * SERVER.JS - O Cérebro do Bot na Nuvem
 * 
 * Instalação:
 * 1. Crie uma pasta.
 * 2. Rode: npm init -y
 * 3. Rode: npm install firebase-admin ws
 * 4. Coloque seu arquivo 'serviceAccountKey.json' do Firebase na mesma pasta.
 * 5. Rode: node server.js
 */

const admin = require('firebase-admin');
const WebSocket = require('ws');
const http = require('http');

// --- CONFIGURAÇÃO FIREBASE ---
// Você precisa gerar a chave privada no console do Firebase:
// Configurações do Projeto > Contas de Serviço > Gerar nova chave privada
let serviceAccount;
try {
    serviceAccount = require('./serviceAccountKey.json');
} catch (e) {
    console.error("❌ ERRO CRÍTICO: O arquivo 'serviceAccountKey.json' não foi encontrado.");
    console.error("Por favor, baixe a chave no Firebase Console > Configurações > Contas de Serviço.");
    process.exit(1);
}

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://nibinbot-default-rtdb.firebaseio.com" // <--- VERIFIQUE SE ESTE URL É O DO SEU PROJETO!
});

const db = admin.database();

// Armazena as sessões ativas dos usuários
// Formato: { 'token_usuario': { ws: WebSocket, config: Object } }
const activeSessions = {};

console.log("🤖 Servidor do Bot Iniciado. Aguardando comandos...");

// --- ESCUTAR COMANDOS DO SITE ---
db.ref('bot_sessions').on('child_changed', (snapshot) => {
    const userId = snapshot.key;
    const data = snapshot.val();
    
    if (!data.cloud_command) return;

    const command = data.cloud_command;

    if (command.status === 'RUNNING') {
        // O usuário clicou em "Rodar na Nuvem"
        if (!activeSessions[userId]) {
            console.log(`[${userId}] Iniciando bot na nuvem...`);
            startBotSession(userId, command.token, command.config);
        } else {
            console.log(`[${userId}] Bot já está rodando. Atualizando configs...`);
            activeSessions[userId].config = command.config;
        }
    } else if (command.status === 'STOPPED') {
        // O usuário clicou em "Parar" (ou fechou a conta)
        if (activeSessions[userId]) {
            console.log(`[${userId}] Parando bot na nuvem...`);
            stopBotSession(userId);
        }
    }
});

// --- LÓGICA DO BOT (SESSÃO INDIVIDUAL) ---
function startBotSession(userId, token, config) {
    const ws = new WebSocket('wss://ws.binaryws.com/websockets/v3?app_id=1089');
    
    const session = {
        ws: ws,
        config: config,
        // Estado completo igual ao do site
        state: {
            dailyProfit: 0,
            wins: 0,
            losses: 0,
            tradesToday: 0,
            consecutiveLosses: 0,
            priceHistory: [],
            currentPrice: 0,
            isWaitingForRecovery: false,
            balance: 0,
            // Estado da Simulação
            simulation: {
                active: false,
                direction: null,
                startTime: 0,
                priceData: [],
                predictionScore: 0,
                priceAtStart: 0
            }
        },
        simulationTimer: null
    };

    activeSessions[userId] = session;

    ws.on('open', () => {
        console.log(`[${userId}] Conectado à Deriv.`);
        ws.send(JSON.stringify({ authorize: token }));
    });

    ws.on('message', (msg) => {
        const data = JSON.parse(msg);

        if (data.error) {
            console.error(`[${userId}] Erro: ${data.error.message}`);
            logToFirebase(userId, `Erro: ${data.error.message}`, 'error');
            return;
        }

        if (data.msg_type === 'authorize') {
            console.log(`[${userId}] Autorizado.`);
            logToFirebase(userId, 'Bot rodando na nuvem 24h', 'success');
            ws.send(JSON.stringify({ balance: 1, subscribe: 1 }));
            const symbol = config.symbol || 'frxEURUSD';
            ws.send(JSON.stringify({ ticks: symbol, subscribe: 1 }));
        }

        if (data.msg_type === 'balance') {
            session.state.balance = data.balance.balance;
            console.log(`[${userId}] Saldo: ${session.state.balance} USD`);
        }

        if (data.msg_type === 'buy') {
            console.log(`[${userId}] Ordem executada! ID: ${data.buy.contract_id}`);
            // IMPORTANTE: Inscrever para saber se ganhou ou perdeu
            ws.send(JSON.stringify({
                proposal_open_contract: 1,
                contract_id: data.buy.contract_id,
                subscribe: 1
            }));
        }

        if (data.msg_type === 'tick') {
            const price = data.tick.quote;
            session.state.currentPrice = price;
            session.state.priceHistory.push(price);
            if (session.state.priceHistory.length > 100) session.state.priceHistory.shift();
            
            // --- ESTRATÉGIA SIMPLES DE TESTE ---
            // Se não houver contrato aberto, tenta comprar algo
            // ATENÇÃO: Isso é apenas um exemplo para testar se a ordem entra!
            if (!session.openContract) {
                // Exemplo: Se o preço subiu nos últimos 2 ticks, compra CALL
                const history = session.state.priceHistory;
                if (history.length > 2) {
                    const lastPrice = history[history.length - 1];
                    const prevPrice = history[history.length - 2];
                    const direction = lastPrice > prevPrice ? 'CALL' : 'PUT';
                    
                    console.log(`[${userId}] Tentando comprar ${direction}...`);
                    buyContract(ws, config, session, direction);
                    session.openContract = true; // Marca que já comprou para não comprar infinitamente
                }
            }
        }

        if (data.msg_type === 'proposal_open_contract') {
            const contract = data.proposal_open_contract;
            if (contract.is_sold) {
                const profit = contract.profit;
                session.state.dailyProfit += profit;
                session.openContract = false; // Libera para comprar novamente
                
                if (profit > 0) session.state.wins++;
                else session.state.losses++;

                // Atualiza o site com o novo lucro
                updateStatsOnFirebase(userId, session.state);
                
                logToFirebase(userId, `Trade finalizado: ${profit} USD`, profit > 0 ? 'success' : 'error');

                // Verifica Stop/Win
                if (session.state.dailyProfit >= config.takeProfit) {
                    logToFirebase(userId, 'Meta batida! Parando bot.', 'success');
                    stopBotSession(userId);
                }
            }
        }
    });

    ws.on('close', () => {
        console.log(`[${userId}] Desconectado.`);
        // Tentar reconectar se não foi parado manualmente
        if (activeSessions[userId]) {
            setTimeout(() => startBotSession(userId, token, config), 5000);
        }
    });
}

function stopBotSession(userId) {
    if (activeSessions[userId]) {
        if (activeSessions[userId].ws) {
            activeSessions[userId].ws.close();
        }
        if (activeSessions[userId].simulationTimer) {
            clearInterval(activeSessions[userId].simulationTimer);
        }
        
        delete activeSessions[userId];
        
        // Avisa o site que parou
        db.ref(`bot_sessions/${userId}/cloud_command/status`).set('STOPPED');
    }
}

function buyContract(ws, config, session, direction) {
    // Calcula 10% do saldo como o retorno esperado
    const tenPercentProfit = session.state.balance * 0.10;
    
    ws.send(JSON.stringify({
        buy: 1,
        price: tenPercentProfit,  // 10% do saldo como retorno esperado
        parameters: {
            amount: config.stake,
            basis: 'stake',
            contract_type: direction,
            currency: 'USD',
            duration: 5,
            duration_unit: 't',
            symbol: config.symbol
        }
    }));
}

function logToFirebase(userId, msg, type) {
    const time = new Date().toLocaleTimeString('pt-BR');
    db.ref(`bot_sessions/${userId}/logs`).push({ time, msg, type });
}

function updateStatsOnFirebase(userId, stats) {
    db.ref(`bot_sessions/${userId}`).update({
        dailyProfit: stats.dailyProfit,
        wins: stats.wins,
        losses: stats.losses
    });
}

// --- SERVIDOR WEB & DASHBOARD (INTERFACE VISUAL) ---
// Transforma o servidor em um site onde você pode controlar o bot
const port = process.env.PORT || 8080;

const HTML_DASHBOARD = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Bot Deriv</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #f1f5f9; display: flex; flex-direction: column; align-items: center; padding: 20px; }
        .container { max-width: 600px; width: 100%; background: #1e293b; padding: 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }
        h1 { text-align: center; color: #38bdf8; margin-bottom: 20px; }
        input, select { width: 100%; padding: 12px; margin: 8px 0; background: #334155; border: 1px solid #475569; color: white; border-radius: 6px; }
        button { width: 100%; padding: 15px; margin-top: 15px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-start { background: #10b981; color: white; }
        .btn-stop { background: #ef4444; color: white; }
        .btn-start:hover { background: #059669; }
        .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px; }
        .stat-card { background: #0f172a; padding: 15px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 1.5em; font-weight: bold; }
        .profit-pos { color: #10b981; } .profit-neg { color: #ef4444; }
        #logs { margin-top: 20px; height: 150px; overflow-y: auto; background: #020617; padding: 10px; font-family: monospace; font-size: 0.9em; border-radius: 6px; border: 1px solid #334155; }
        .log-entry { margin-bottom: 4px; border-bottom: 1px solid #1e293b; padding-bottom: 2px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 Painel de Controle Deriv</h1>
        
        <div id="controlPanel">
            <label>Token da API Deriv:</label>
            <input type="password" id="token" placeholder="Cole seu token aqui">
            
            <label>Símbolo Deriv:</label>
            <select id="symbol">
                <option value="frxEURUSD">EUR/USD (frxEURUSD)</option>
                <option value="frxGBPUSD">GBP/USD (frxGBPUSD)</option>
                <option value="frxAUDUSD">AUD/USD (frxAUDUSD)</option>
                <option value="frxUSDJPY">USD/JPY (frxUSDJPY)</option>
                <option value="frxUSDCAD">USD/CAD (frxUSDCAD)</option>
            </select>
            
            <label>Stake (USD):</label>
            <input type="number" id="stake" value="0.35" step="0.01">
            
            <label>Meta Lucro (USD):</label>
            <input type="number" id="takeProfit" value="5.00" step="0.1">
            
            <label>Stop Loss (USD):</label>
            <input type="number" id="stopLoss" value="-100" step="0.1">
            
            <label>Taxa de Acerto (%):</label>
            <input type="number" id="winRate" value="55" step="1" min="0" max="100">

            <button onclick="startBot()" class="btn-start" id="btnAction">▶️ INICIAR BOT</button>
            <button onclick="stopBot()" class="btn-stop" style="display:none;" id="btnStop">⏹️ PARAR BOT</button>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div>Lucro Total</div>
                <div id="profitDisplay" class="stat-value">0.00 USD</div>
            </div>
            <div class="stat-card">
                <div>Placar (W/L)</div>
                <div id="scoreDisplay" class="stat-value">0 / 0</div>
            </div>
        </div>

        <div id="logs">
            <div class="log-entry" style="color: #94a3b8;">Aguardando início...</div>
        </div>
    </div>

    <script>
        // Gera um ID único para este navegador para não misturar com outros usuários
        let clientId = localStorage.getItem('botClientId');
        if (!clientId) {
            clientId = 'user_' + Math.random().toString(36).substr(2, 9);
            localStorage.setItem('botClientId', clientId);
        }

        let isRunning = false;
        
        async function startBot() {
            const token = document.getElementById('token').value;
            const symbol = document.getElementById('symbol').value;
            const stake = parseFloat(document.getElementById('stake').value);
            const takeProfit = parseFloat(document.getElementById('takeProfit').value);
            const stopLoss = parseFloat(document.getElementById('stopLoss').value);
            const winRate = parseFloat(document.getElementById('winRate').value);
            
            if(!token) return alert('Digite o Token!');

            document.getElementById('btnAction').style.display = 'none';
            document.getElementById('btnStop').style.display = 'block';
            
            await fetch('/api/start', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ 
                    clientId, // Envia o ID único
                    token, 
                    config: { stake, takeProfit, symbol, stopLoss, winRate } 
                })
            });
            
            isRunning = true;
            updateStats();
        }

        async function stopBot() {
            await fetch('/api/stop', { 
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ clientId }) 
            });
            document.getElementById('btnAction').style.display = 'block';
            document.getElementById('btnStop').style.display = 'none';
            isRunning = false;
        }

        async function updateStats() {
            if(!isRunning) return;
            
            try {
                const res = await fetch('/api/stats?clientId=' + clientId);
                const data = await res.json();
                
                if(data.active) {
                    const profitEl = document.getElementById('profitDisplay');
                    profitEl.innerText = data.dailyProfit.toFixed(2) + ' USD';
                    profitEl.className = 'stat-value ' + (data.dailyProfit >= 0 ? 'profit-pos' : 'profit-neg');
                    
                    document.getElementById('scoreDisplay').innerText = \`\${data.wins} / \${data.losses}\`;
                    
                    // Logs simples (último preço)
                    const logsDiv = document.getElementById('logs');
                    const logEntry = document.createElement('div');
                    logEntry.className = 'log-entry';
                    logEntry.innerText = \`[\${new Date().toLocaleTimeString()}] Preço: \${data.currentPrice}\`;
                    logsDiv.prepend(logEntry);
                }
            } catch(e) { console.error(e); }
            
            setTimeout(updateStats, 2000);
        }
    </script>
</body>
</html>
`;

const server = http.createServer((req, res) => {
    // 1. Rota Principal: Entrega o HTML do Dashboard
    if (req.method === 'GET' && req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(HTML_DASHBOARD);
        return;
    }

    // 2. API: Iniciar Bot
    if (req.method === 'POST' && req.url === '/api/start') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { clientId, token, config } = JSON.parse(body);
            // Usa o ID único enviado pelo navegador
            const userId = clientId || 'web-user'; 
            startBotSession(userId, token, config);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ status: 'started' }));
        });
        return;
    }

    // 3. API: Parar Bot
    if (req.method === 'POST' && req.url === '/api/stop') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { clientId } = JSON.parse(body || '{}');
            const userId = clientId || 'web-user';
            stopBotSession(userId);
            res.writeHead(200);
            res.end(JSON.stringify({ status: 'stopped' }));
        });
        return;
    }

    // 4. API: Pegar Estatísticas
    if (req.method === 'GET' && req.url.startsWith('/api/stats')) {
        const urlParts = req.url.split('?');
        const query = new URLSearchParams(urlParts[1]);
        const userId = query.get('clientId') || 'web-user';
        
        const session = activeSessions[userId];
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if (session) {
            res.end(JSON.stringify({ active: true, ...session.state }));
        } else {
            res.end(JSON.stringify({ active: false }));
        }
        return;
    }
});

server.listen(port, () => console.log(`🌍 Painel de Controle rodando na porta ${port}`));