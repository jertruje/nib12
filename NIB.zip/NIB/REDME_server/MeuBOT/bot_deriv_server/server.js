/**
 * SERVER.JS - O Cérebro do Bot na Nuvem
 * BOT RODA 24H MESMO COM SITE FECHADO - SEM FIREBASE
 * 
 * Instalação:
 * 1. Crie uma pasta.
 * 2. Rode: npm init -y
 * 3. Rode: npm install ws
 * 4. Rode: node server.js
 * 5. Abra http://localhost:8080 no navegador
 */

const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

// --- CONFIGURAÇÃO LOCAL (SEM FIREBASE) ---
const DATA_FILE = path.join(__dirname, 'users.json');

// Carregar dados de usuários
function loadUsersData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        }
    } catch (e) {
        console.warn('⚠️ Erro ao carregar dados locais, usando padrão vazio.');
    }
    return {};
}

// Salvar dados de usuários
function saveUsersData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

let usersData = loadUsersData();


// Armazena as sessões ativas dos usuários
// Formato: { 'userId': { ws: WebSocket, config: Object, state: {...} } }
const activeSessions = {};

console.log("🤖 Servidor do Bot Iniciado. Aguardando comandos...");
console.log("📊 Gerenciador Local de Usuários (SEM FIREBASE)");


// --- LÓGICA DO BOT (SESSÃO INDIVIDUAL) ---
function startBotSession(userId, token, config) {
    const ws = new WebSocket('wss://ws.binaryws.com/websockets/v3?app_id=1089');

    // Encontrar o username correspondente ao userId
    const userName = Object.keys(usersData).find(u => usersData[u].userId === userId);
    if (!userName) {
        console.error(`❌ [${userId}] Usuário não encontrado no banco de dados!`);
        return;
    }

    // --- APLICAÇÃO DO NÍVEL DE SEGURANÇA E RISCO ---
    const securityLevel = config.securityLevel || 50;
    const riskLevel = config.riskLevel || 50;
    
    // Segurança (10-100%): Controla os sinais (mais seguro = mais rigoroso)
    const rsiOffset = ((securityLevel - 10) / 90) * 15;  // -15 a +15
    
    // Risco (10-100%): Controla o tamanho da aposta e frequência
    const riskMultiplier = riskLevel / 50;  // 0.2x em 10%, 1x em 50%, 2x em 100%
    const stakeBase = config.stake || 0.35;
    const finalStake = Math.max(0.35, stakeBase * riskMultiplier);
    
    // Configuração Ajustada
    const botConfig = {
        ...config,
        rsiLow: 30 - rsiOffset,   // RSI mais tolerante em segurança baixa
        rsiHigh: 70 + rsiOffset,  // RSI mais exigente em segurança alta
        stake: finalStake,
        maxTrades: Math.floor(50 + (riskLevel - 10) * 0.5),  // 50 a 75 trades conforme risco
        // Stop Loss ajustado pelo risco: risco alto = stop loss menor (mais agressivo)
        stopLoss: config.stopLoss || (-150 + (riskLevel - 10) * 0.5),
        // Take Profit se não foi definido, usa o default
        takeProfit: config.takeProfit || 5.00
    };

    console.log(`[${userName}] Config ajustada - Segurança ${securityLevel}% Risco ${riskLevel}% | RSI ${botConfig.rsiLow.toFixed(1)}/${botConfig.rsiHigh.toFixed(1)}, Stake $${botConfig.stake.toFixed(2)}, Max ${botConfig.maxTrades} trades`);
    
    // Inicializa estado a partir do armazenamento local, se existir
    const savedStats = (usersData[userName] && usersData[userName].stats) ? usersData[userName].stats : {};

    const session = {
        userId: userId,
        userName: userName,
        ws: ws,
        config: botConfig,
        openContract: false,
        state: {
            dailyProfit: savedStats.dailyProfit || 0,
            wins: savedStats.wins || 0,
            losses: savedStats.losses || 0,
            tradesToday: savedStats.tradesToday || 0,
            consecutiveLosses: 0,
            priceHistory: [],
            currentPrice: 0,
            balance: savedStats.balance || 0,
            isWaitingForRecovery: false,
            simulation: {
                active: false,
                direction: null,
                startTime: 0,
                priceData: [],
                predictionScore: 0,
                priceAtStart: 0,
                timer: null
            }
        },
        strategyTimer: null
    };

    activeSessions[userId] = session;

    ws.on('open', () => {
        console.log(`[${userName}] 🔗 Conectado ao servidor Deriv com sucesso!`);
        logToLocal(userName, 'Conectado ao Deriv', 'info');
        ws.send(JSON.stringify({ authorize: token }));
    });

    ws.on('message', (msg) => {
        const data = JSON.parse(msg);

        if (data.error) {
            // Logar detalhe completo para diagnóstico
            console.error(`[${userName}] Erro API Deriv:`, JSON.stringify(data));
            const errMsg = data.error && data.error.message ? data.error.message : JSON.stringify(data.error || data);
            logToLocal(userName, `Erro API: ${errMsg}`, 'error');
            return;
        }

        if (data.msg_type === 'authorize') {
            console.log(`[${userName}] Autorizado.`);
            logToLocal(userName, 'Bot rodando na nuvem 24h', 'success');
            ws.send(JSON.stringify({ balance: 1, subscribe: 1 }));
            ws.send(JSON.stringify({ ticks: botConfig.symbol || 'R_100', subscribe: 1 }));
        }

        if (data.msg_type === 'buy') {
            console.log(`[${userName}] ✅ ORDEM EXECUTADA! Contract ID: ${data.buy.contract_id}`);
            logToLocal(userName, `Ordem executada! ID: ${data.buy.contract_id}`, 'info');
            // IMPORTANTE: Inscrever para saber se ganhou ou perdeu
            ws.send(JSON.stringify({
                proposal_open_contract: 1,
                contract_id: data.buy.contract_id,
                subscribe: 1
            }));
        }

        if (data.msg_type === 'balance') {
                session.state.balance = data.balance.balance;
                console.log(`[${userName}] Saldo atualizado: $${session.state.balance.toFixed(2)}`);
                // persistir saldo para exibição após reinício
                if (usersData[userName]) {
                    usersData[userName].stats = usersData[userName].stats || {};
                    usersData[userName].stats.balance = session.state.balance;
                    saveUsersData(usersData);
                }
        }

        if (data.msg_type === 'tick') {
            const price = data.tick.quote;
            session.state.currentPrice = price;
            session.state.priceHistory.push(price);
            if (session.state.priceHistory.length > 100) session.state.priceHistory.shift();
        }

        if (data.msg_type === 'proposal_open_contract') {
            const contract = data.proposal_open_contract;
            if (contract.is_sold) {
                const profit = contract.profit;
                session.state.dailyProfit += profit;
                session.openContract = false; // Libera para comprar novamente
                session.state.tradesToday++;
                
                if (profit > 0) {
                    session.state.wins++;
                    session.state.consecutiveLosses = 0;
                    console.log(`[${userName}] ✅ GANHOU! +${profit} USD (Total: ${session.state.dailyProfit} USD)`);
                } else {
                    session.state.losses++;
                    session.state.consecutiveLosses++;
                    console.log(`[${userName}] ❌ PERDEU! ${profit} USD (Total: ${session.state.dailyProfit} USD)`);
                }

                // Atualiza arquivo local com o novo lucro
                updateLocalStatsFile(userName, session.state);
                
                logToLocal(userName, `Trade finalizado: ${profit} USD`, profit > 0 ? 'success' : 'error');
            }
        }
    });

    ws.on('close', () => {
        console.log(`[${userName}] Desconectado.`);
        // Tentar reconectar se não foi parado manualmente
        if (activeSessions[userId]) {
            clearInterval(session.strategyTimer);
            if (session.state.simulation.timer) clearInterval(session.state.simulation.timer);
            setTimeout(() => startBotSession(userId, token, botConfig), 5000);
        }
    });

    // --- LOOP DA ESTRATÉGIA (A CADA 1 SEGUNDO) ---
    session.strategyTimer = setInterval(() => {
        const state = session.state;
        const conf = session.config;

        // 1. Verificações de Segurança e Limites
        if (session.openContract || state.simulation.active) return;
        
        if (state.tradesToday >= conf.maxTrades) {
            // Apenas loga uma vez por minuto para não spammar
            if (Math.random() > 0.95) console.log(`[${userId}] Limite de trades atingido.`);
            return;
        }

        if (state.dailyProfit >= conf.takeProfit) {
            logToLocal(userName, 'Meta batida! Parando bot.', 'success');
            stopBotSession(userId);
            return;
        }

        if (state.dailyProfit <= conf.stopLoss) {
            logToLocal(userName, 'Stop Loss atingido! Parando bot.', 'error');
            stopBotSession(userId);
            return;
        }

        if (state.consecutiveLosses >= 5) {
            logToLocal(userName, '5 perdas consecutivas. Pausando segurança.', 'error');
            stopBotSession(userId);
            return;
        }

        // 2. Dados Insuficientes
        if (state.priceHistory.length < 14) {
            if (Math.random() > 0.98) console.log(`[${userName}] Coletando dados... (${state.priceHistory.length}/14)`);
            return;
        }

        // 3. Cálculo de Indicadores
        const prices = state.priceHistory;
        const rsi = calculateRSI(prices, 14);
        const volatility = calculateVolatility(prices.slice(-14));

        // 4. Filtros de Mercado (MUITO MAIS RELAXADOS)
        const volatilityThreshold = 0.01;  // Limite bem mais alto
        if (volatility >= volatilityThreshold) {
            if (Math.random() > 0.99) console.log(`[${userName}] Volatilidade alta ${(volatility*100).toFixed(2)}% - bloqueando`);
            return;
        }

        // 5. Lógica de Entrada (MUITO SENSÍVEL) - Apenas RSI
        let signal = null;

        // CALL: RSI < 40
        if (rsi < 40) {
            signal = 'CALL';
        }
        // PUT: RSI > 60
        else if (rsi > 60) {
            signal = 'PUT';
        }

        // 6. Iniciar Simulação se houver sinal
        if (signal) {
            console.log(`[${userName}] ✅ SINAL ${signal}! RSI: ${rsi.toFixed(2)}`);
            logToLocal(userName, `Sinal ${signal} - RSI: ${rsi.toFixed(2)}`, 'info');
            startSimulation(userId, session, signal, userName);
        }

    }, 1000);
}

function startSimulation(userId, session, direction, userName) {
    const sim = session.state.simulation;
    const riskLevel = session.config.riskLevel || 50;
    
    // Score mínimo para aprovar trade: MUITO MAIS BAIXO para facilitar
    const minScore = 15;  // Aceita aprovar mesmo com score baixo
    const timeLimit = 0.3;  // Muito rápido (300ms)
    
    sim.active = true;
    sim.direction = direction;
    sim.startTime = Date.now();
    sim.priceData = [];
    sim.predictionScore = 0;
    sim.priceAtStart = session.state.currentPrice;
    
    // Loop da Simulação (roda a cada 100ms)
    sim.timer = setInterval(() => {
        const elapsed = (Date.now() - sim.startTime) / 1000;
        
        // Coleta dados
        sim.priceData.push({ time: elapsed, price: session.state.currentPrice });

        // Analisa Tendência (últimos 4 pontos)
        if (sim.priceData.length > 3) {
            const recent = sim.priceData.slice(-4);
            let avgChange = 0;
            for (let i = 1; i < recent.length; i++) {
                avgChange += ((recent[i].price - recent[i-1].price) / recent[i-1].price) * 100;
            }
            avgChange /= (recent.length - 1);

            let isFavorable = (direction === 'CALL' && avgChange > 0.001) || (direction === 'PUT' && avgChange < -0.001);
            
            // Atualiza Score
            sim.predictionScore = isFavorable ? Math.min(100, sim.predictionScore + 20) : Math.max(0, sim.predictionScore - 15);
        }

        // Finaliza após tempo determinado ou se atingir score
        if (elapsed >= timeLimit || sim.predictionScore >= minScore) {
            clearInterval(sim.timer);
            sim.active = false;
            
            if (sim.predictionScore >= minScore) {
                console.log(`[${userName}] ✅ SIMULAÇÃO APROVADA (Score: ${sim.predictionScore}%, Min: ${minScore}%). EXECUTANDO ${direction}!`);
                logToLocal(userName, `Trade aprovado! Score: ${sim.predictionScore}%`, 'success');
                buyContract(session.ws, session.config, direction);
                session.openContract = true;
            } else {
                console.log(`[${userName}] ❌ Simulação REJEITADA (Score: ${sim.predictionScore}%, Min: ${minScore}%).`);
            }
        }
    }, 100);
}

function stopBotSession(userId) {
    if (activeSessions[userId]) {
        const session = activeSessions[userId];
        const userName = session.userName;
        
        if (session.ws) {
            session.ws.close();
        }
        if (session.strategyTimer) {
            clearInterval(session.strategyTimer);
        }
        if (session.state.simulation.timer) {
            clearInterval(session.state.simulation.timer);
        }
        
        // Salva estatísticas finais
        updateLocalStatsFile(userName, session.state);
        // marca como parado para não ser restaurado automaticamente
        if (usersData[userName]) {
            usersData[userName].isRunning = false;
            saveUsersData(usersData);
        }
        delete activeSessions[userId];
        console.log(`[${userName}] Bot parado.`);
    }
}

function buyContract(ws, config, direction) {
    // Ajuste de Stake em caso de perdas consecutivas (Gestão de Risco)
    // Se tiver 3 ou mais perdas, reduz a stake pela metade (mínimo 0.35 ou config)
    // Nota: O código original do cliente reduz stake. Aqui simplificamos para usar o config.stake já ajustado.
    
    // Mapeia CALL/PUT para contrato Deriv
    const contractType = direction === 'CALL' ? 'CALL' : 'PUT';
    const symbol = config.symbol || 'R_100';

    const payload = {
        buy: 1,
        price: 1000,
        amount: config.stake,
        basis: 'stake',
        contract_type: contractType,
        currency: 'USD',
        duration: 5,
        duration_unit: 't',
        symbol: symbol
    };

    console.log(`🎯 EXECUTANDO TRADE ${direction} - Stake: $${config.stake}, Symbol: ${symbol}`);

    try {
        // tenta achar sessão associada ao ws para melhorar logs
        const sess = Object.values(activeSessions).find(s => s.ws === ws);
        const uname = sess ? sess.userName : 'unknown';

        if (!ws || ws.readyState !== WebSocket.OPEN) {
            console.error('⚠️ WebSocket não está aberto para enviar ordem.');
            logToLocal(uname, 'WS não aberto ao tentar comprar', 'error');
            return;
        }
        // Envia payload e registra o que foi enviado para facilitar debug
        ws.send(JSON.stringify(payload));
        logToLocal(uname, `Ordem enviada: ${JSON.stringify(payload)}`, 'info');
    } catch (err) {
        console.error('Erro ao enviar ordem:', err && err.message ? err.message : err);
        const sess = Object.values(activeSessions).find(s => s.ws === ws);
        const uname = sess ? sess.userName : 'unknown';
        logToLocal(uname, `Erro ao enviar ordem: ${err && err.message ? err.message : JSON.stringify(err)}`, 'error');
    }
}

function logToLocal(userName, msg, type) {
    const time = new Date().toLocaleTimeString('pt-BR');
    
    if (!usersData[userName]) {
        console.error(`❌ Erro: Usuário ${userName} não encontrado em usersData!`);
        return;
    }
    
    if (!usersData[userName].logs) {
        usersData[userName].logs = [];
    }
    
    usersData[userName].logs.push({ time, msg, type });
    
    // Manter apenas os últimos 50 logs
    if (usersData[userName].logs.length > 50) {
        usersData[userName].logs.shift();
    }
    
    saveUsersData(usersData);
    console.log(`[${userName}] ${type.toUpperCase()}: ${msg}`);
}

function updateLocalStatsFile(userName, stats) {
    if (!usersData[userName]) {
        console.error(`❌ Erro: Usuário ${userName} não encontrado em usersData!`);
        return;
    }
    
    usersData[userName].stats = {
        dailyProfit: stats.dailyProfit,
        wins: stats.wins,
        losses: stats.losses,
        tradesToday: stats.tradesToday,
        balance: stats.balance || (usersData[userName].stats && usersData[userName].stats.balance) || 0,
        lastUpdate: new Date().toISOString()
    };
    
    saveUsersData(usersData);
}

// --- FUNÇÕES MATEMÁTICAS (INDICADORES) ---
function calculateSMA(prices, period) {
    if (prices.length < period) return null;
    const sum = prices.slice(-period).reduce((a, b) => a + b, 0);
    return sum / period;
}

function calculateEMA(prices, period) {
    if (prices.length < period) return null;
    const multiplier = 2 / (period + 1);
    let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
    for (let i = period; i < prices.length; i++) {
        ema = (prices[i] - ema) * multiplier + ema;
    }
    return ema;
}

function calculateRSI(prices, period = 14) {
    if (prices.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = prices.length - period; i < prices.length; i++) {
        const change = prices[i] - prices[i - 1];
        if (change >= 0) gains += change;
        else losses += Math.abs(change);
    }
    const avgGain = gains / period;
    const avgLoss = losses / period;
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
}

function calculateBollingerBands(prices, period = 20, stdDevMultiplier = 2) {
    if (prices.length < period) return null;
    const sma = calculateSMA(prices, period);
    const slice = prices.slice(-period);
    const variance = slice.reduce((sum, price) => sum + Math.pow(price - sma, 2), 0) / period;
    const stdDev = Math.sqrt(variance);
    return { upper: sma + (stdDevMultiplier * stdDev), middle: sma, lower: sma - (stdDevMultiplier * stdDev) };
}

function calculateVolatility(prices) {
    if (prices.length < 2) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance) / mean;
}

function calculateMACD(prices) {
    if (prices.length < 35) return { macd: 0, signal: 0, histogram: 0 };
    const ema12 = calculateEMA(prices, 12);
    const ema26 = calculateEMA(prices, 26);
    if (ema12 === null || ema26 === null) return { macd: 0, signal: 0, histogram: 0 };
    const macd = ema12 - ema26;
    
    // Signal line (EMA9 of MACD)
    const macdHistory = [];
    // Recalcula MACD histórico para obter a linha de sinal (aproximação)
    for (let i = 25; i < prices.length; i++) {
        const slice = prices.slice(0, i + 1);
        const e12 = calculateEMA(slice, 12);
        const e26 = calculateEMA(slice, 26);
        if (e12 !== null && e26 !== null) macdHistory.push(e12 - e26);
    }
    
    if (macdHistory.length < 9) return { macd, signal: 0, histogram: 0 };
    const signal = calculateEMA(macdHistory, 9);
    if (signal === null) return { macd, signal: 0, histogram: 0 };
    
    return { macd, signal, histogram: macd - signal };
}

// --- SERVIDOR WEB & DASHBOARD (INTERFACE VISUAL) ---
// Transforma o servidor em um site onde você pode controlar o bot
const port = process.env.PORT || 8080;

const HTML_LOGIN = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bot Deriv - Login</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #f1f5f9; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }
        .container { max-width: 400px; width: 100%; background: #1e293b; padding: 40px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); text-align: center; }
        h1 { color: #38bdf8; margin-bottom: 30px; }
        input { width: 100%; padding: 12px; margin: 10px 0; background: #334155; border: 1px solid #475569; color: white; border-radius: 6px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; margin-top: 15px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; transition: 0.2s; background: #38bdf8; color: #0f172a; }
        button:hover { background: #22d3ee; }
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; }
        .tab { flex: 1; padding: 10px; background: #334155; color: white; cursor: pointer; border-radius: 6px; border: 2px solid transparent; }
        .tab.active { background: #38bdf8; color: #0f172a; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .error { color: #ef4444; margin: 10px 0; }
        .success { color: #10b981; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 Bot Deriv</h1>
        
        <div class="tabs">
            <div class="tab active" onclick="switchTab('login')">Login</div>
            <div class="tab" onclick="switchTab('register')">Criar Conta</div>
        </div>

        <div id="login" class="tab-content active">
            <input type="text" id="loginUser" placeholder="Usuário" />
            <input type="password" id="loginPass" placeholder="Senha" />
            <div id="loginMsg"></div>
            <button onclick="login()">Entrar</button>
        </div>

        <div id="register" class="tab-content">
            <input type="text" id="regUser" placeholder="Novo Usuário" />
            <input type="password" id="regPass" placeholder="Senha" />
            <input type="password" id="regPassConfirm" placeholder="Confirmar Senha" />
            <div id="regMsg"></div>
            <button onclick="register()">Criar Conta</button>
        </div>
    </div>

    <script>
        function switchTab(tab) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
            document.getElementById(tab).classList.add('active');
            event.target.classList.add('active');
        }

        async function login() {
            const user = document.getElementById('loginUser').value;
            const pass = document.getElementById('loginPass').value;
            if(!user || !pass) return alert('Preencha todos os campos!');
            
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ user, pass })
            });
            const data = await res.json();
            const msgEl = document.getElementById('loginMsg');
            
            if(data.success) {
                localStorage.setItem('userId', data.userId);
                localStorage.setItem('token', data.token);
                window.location.href = '/dashboard';
            } else {
                msgEl.className = 'error';
                msgEl.innerText = data.error || 'Erro ao fazer login';
            }
        }

        async function register() {
            const user = document.getElementById('regUser').value;
            const pass = document.getElementById('regPass').value;
            const passConfirm = document.getElementById('regPassConfirm').value;
            
            if(!user || !pass) return alert('Preencha todos os campos!');
            if(pass !== passConfirm) return alert('Senhas não conferem!');
            
            const res = await fetch('/api/register', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ user, pass })
            });
            const data = await res.json();
            const msgEl = document.getElementById('regMsg');
            
            if(data.success) {
                msgEl.className = 'success';
                msgEl.innerText = 'Conta criada! Fazendo login...';
                setTimeout(() => {
                    localStorage.setItem('userId', data.userId);
                    localStorage.setItem('token', data.token);
                    window.location.href = '/dashboard';
                }, 1000);
            } else {
                msgEl.className = 'error';
                msgEl.innerText = data.error || 'Erro ao criar conta';
            }
        }

        // Se já está logado, redirecionar
        if(localStorage.getItem('userId')) window.location.href = '/dashboard';
    </script>
</body>
</html>
`;

const HTML_DASHBOARD = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Bot Deriv</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #f1f5f9; display: flex; flex-direction: column; align-items: center; padding: 20px; }
        .container { max-width: 600px; width: 100%; background: #1e293b; padding: 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        h1 { color: #38bdf8; margin: 0; }
        .logout-btn { background: #ef4444; color: white; padding: 8px 15px; border-radius: 6px; cursor: pointer; border: none; }
        input, select { width: 100%; padding: 12px; margin: 8px 0; background: #334155; border: 1px solid #475569; color: white; border-radius: 6px; box-sizing: border-box; }
        input[type="range"] { padding: 0; height: 6px; }
        .slider-container { margin: 15px 0; }
        .slider-label { display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 0.9em; }
        .slider-value { color: #38bdf8; font-weight: bold; }
        button { width: 100%; padding: 15px; margin-top: 15px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-start { background: #10b981; color: white; }
        .btn-stop { background: #ef4444; color: white; }
        .btn-start:hover { background: #059669; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 15px; margin-top: 20px; }
        .stat-card { background: #0f172a; padding: 15px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 1.5em; font-weight: bold; }
        .profit-pos { color: #10b981; } .profit-neg { color: #ef4444; }
        #logs { margin-top: 20px; height: 150px; overflow-y: auto; background: #020617; padding: 10px; font-family: monospace; font-size: 0.9em; border-radius: 6px; border: 1px solid #334155; }
        .log-entry { margin-bottom: 4px; border-bottom: 1px solid #1e293b; padding-bottom: 2px; }
        @media (max-width: 600px) {
            .stats-grid { grid-template-columns: 1fr; }
            #controlPanel > div { grid-template-columns: 1fr !important; }
            .container { padding: 15px; }
            h1 { font-size: 1.5em; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 Painel de Controle Deriv</h1>
            <button class="logout-btn" onclick="logout()">Sair</button>
        </div>
        
        <div id="controlPanel">
            <label>Token da API Deriv:</label>
            <input type="password" id="token" placeholder="Cole seu token aqui">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div>
                    <label>Stake (USD):</label>
                    <input type="number" id="stake" value="0.35" step="0.01">
                </div>
                <div>
                    <label>Meta Lucro (USD):</label>
                    <input type="number" id="takeProfit" value="5.00" step="0.1">
                </div>
            </div>

            <div class="slider-container">
                <div class="slider-label">
                    <label>🛡️ Segurança:</label>
                    <span class="slider-value"><span id="securityValue">50</span>%</span>
                </div>
                <input type="range" id="securityLevel" min="10" max="100" value="50" step="5" 
                       oninput="document.getElementById('securityValue').innerText = this.value">
            </div>

            <div class="slider-container">
                <div class="slider-label">
                    <label>⚡ Risco:</label>
                    <span class="slider-value"><span id="riskValue">50</span>%</span>
                </div>
                <input type="range" id="riskLevel" min="10" max="100" value="50" step="5"
                       oninput="document.getElementById('riskValue').innerText = this.value">
            </div>

            <button onclick="startBot()" class="btn-start" id="btnAction">▶️ INICIAR BOT</button>
            <button onclick="stopBot()" class="btn-stop" style="display:none;" id="btnStop">⏹️ PARAR BOT</button>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div>Saldo Deriv</div>
                <div id="balanceDisplay" class="stat-value">0.00 USD</div>
            </div>
            <div class="stat-card">
                <div>Lucro Total</div>
                <div id="profitDisplay" class="stat-value">0.00 USD</div>
            </div>
            <div class="stat-card">
                <div>Placar (W/L)</div>
                <div id="scoreDisplay" class="stat-value">0 / 0</div>
            </div>
            <div class="stat-card">
                <div>Assertividade</div>
                <div id="winRateDisplay" class="stat-value">0%</div>
            </div>
        </div>

        <div id="logs">
            <div class="log-entry" style="color: #94a3b8;">Aguardando início...</div>
        </div>
    </div>

    <script>
        const userId = localStorage.getItem('userId');
        const token = localStorage.getItem('token');
        
        if(!userId || !token) window.location.href = '/';
        
        let isRunning = false;
        
        async function startBot() {
            const apiToken = document.getElementById('token').value;
            const stake = parseFloat(document.getElementById('stake').value);
            const takeProfit = parseFloat(document.getElementById('takeProfit').value);
            const securityLevel = parseInt(document.getElementById('securityLevel').value);
            const riskLevel = parseInt(document.getElementById('riskLevel').value);
            
            if(!apiToken) return alert('Digite o Token da API Deriv!');

            const res = await fetch('/api/start', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ 
                    userId,
                    apiToken, 
                    config: { stake, takeProfit, symbol: 'R_100', stopLoss: -100, securityLevel, riskLevel } 
                })
            });
            
            if(res.ok) {
                document.getElementById('btnAction').style.display = 'none';
                document.getElementById('btnStop').style.display = 'block';
                isRunning = true;
                updateStats();
            }
        }

        async function stopBot() {
            const res = await fetch('/api/stop', { 
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ userId }) 
            });
            
            if(res.ok) {
                document.getElementById('btnAction').style.display = 'block';
                document.getElementById('btnStop').style.display = 'none';
                isRunning = false;
            }
        }

        async function updateStats() {
            if(!isRunning) return;
            
            try {
                const res = await fetch('/api/stats?userId=' + userId);
                const data = await res.json();
                
                if(data.active) {                    document.getElementById('balanceDisplay').innerText = (data.balance || 0).toFixed(2) + ' USD';
                                        const profitEl = document.getElementById('profitDisplay');
                    profitEl.innerText = data.dailyProfit.toFixed(2) + ' USD';
                    profitEl.className = 'stat-value ' + (data.dailyProfit >= 0 ? 'profit-pos' : 'profit-neg');
                    
                    document.getElementById('scoreDisplay').innerText = \`\${data.wins} / \${data.losses}\`;
                    
                    const total = data.wins + data.losses;
                    const rate = total > 0 ? Math.round((data.wins / total) * 100) : 0;
                    document.getElementById('winRateDisplay').innerText = rate + '%';
                }
            } catch(e) { console.error(e); }
            
            updateLogs();
            setTimeout(updateStats, 2000);
        }

        async function updateLogs() {
            try {
                const res = await fetch('/api/logs?userId=' + userId);
                const data = await res.json();
                const logsEl = document.getElementById('logs');
                
                if(data.logs && data.logs.length > 0) {
                    logsEl.innerHTML = data.logs.map(log => {
                        let color = '#94a3b8';
                        if(log.type === 'success') color = '#10b981';
                        if(log.type === 'error') color = '#ef4444';
                        if(log.type === 'info') color = '#38bdf8';
                        
                        return \`<div class="log-entry" style="color: \${color};">\${log.time} - \${log.msg}</div>\`;
                    }).join('');
                    logsEl.scrollTop = logsEl.scrollHeight;
                }
            } catch(e) { console.error('Erro ao buscar logs:', e); }
        }

        function logout() {
            localStorage.removeItem('userId');
            localStorage.removeItem('token');
            window.location.href = '/';
        }

        // Carregar configurações salvas
        document.addEventListener('DOMContentLoaded', async () => {
            const res = await fetch('/api/user-config?userId=' + userId);
            const config = await res.json();
            if(config.token) document.getElementById('token').value = config.token;
            if(config.stake) document.getElementById('stake').value = config.stake;
            if(config.takeProfit) document.getElementById('takeProfit').value = config.takeProfit;
            if(config.securityLevel) document.getElementById('securityLevel').value = config.securityLevel;
            if(config.riskLevel) document.getElementById('riskLevel').value = config.riskLevel;
        });
    </script>
</body>
</html>
`;

const server = http.createServer((req, res) => {
    // 2. API: Registrar Novo Usuário
    if (req.method === 'POST' && req.url === '/api/register') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { user, pass } = JSON.parse(body);
            
            if(usersData[user]) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, error: 'Usuário já existe' }));
                return;
            }
            
            const userId = 'user_' + Date.now();
            // Cria token de sessão simples para o painel (não é token da Deriv)
            const sessionToken = Math.random().toString(36).slice(2);
            usersData[user] = { userId, pass, stats: { dailyProfit: 0, wins: 0, losses: 0 }, logs: [], config: {}, sessionToken };
            saveUsersData(usersData);
            
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, userId, token: sessionToken }));
        });
        return;
    }

    // 3. API: Login
    if (req.method === 'POST' && req.url === '/api/login') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { user, pass } = JSON.parse(body);
            
            if(!usersData[user] || usersData[user].pass !== pass) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, error: 'Usuário ou senha inválidos' }));
                return;
            }
            
            const userData = usersData[user];
            // Retorna token de sessão para o painel (garante compatibilidade com o front)
            const sessionToken = userData.sessionToken || Math.random().toString(36).slice(2);
            userData.sessionToken = sessionToken;
            saveUsersData(usersData);

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, userId: userData.userId, token: sessionToken }));
        });
        return;
    }

    // 4. API: Iniciar Bot
    if (req.method === 'POST' && req.url === '/api/start') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            try {
                const { userId, apiToken, config } = JSON.parse(body);
                console.log(`\n🚀 Recebendo requisição de iniciar bot para userId: ${userId}`);
                
                // Salvar configuração do usuário
                const userName = Object.keys(usersData).find(u => usersData[u].userId === userId);
                console.log(`📝 Usuário encontrado: ${userName}`);
                
                if(userName) {
                        usersData[userName].config = { token: apiToken, ...config };
                        // marcar como em execução para restauração futura
                        usersData[userName].isRunning = true;
                        saveUsersData(usersData);
                        console.log(`✅ Configuração salva. Iniciando bot...`);

                        startBotSession(userId, apiToken, config);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ status: 'started', userId, userName }));
                } else {
                    console.error(`❌ Usuário com ID ${userId} não encontrado!`);
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: 'Usuário não encontrado' }));
                }
            } catch(e) {
                console.error(`❌ Erro ao processar início do bot:`, e.message);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: e.message }));
            }
        });
        return;
    }

    // 5. API: Parar Bot
    if (req.method === 'POST' && req.url === '/api/stop') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { userId } = JSON.parse(body || '{}');
            stopBotSession(userId);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ status: 'stopped' }));
        });
        return;
    }

    // 6. API: Pegar Estatísticas
    if (req.method === 'GET' && req.url.startsWith('/api/stats')) {
        const urlParts = req.url.split('?');
        const query = new URLSearchParams(urlParts[1]);
        const userId = query.get('userId');
        
        const session = activeSessions[userId];
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if (session) {
            res.end(JSON.stringify({ active: true, ...session.state }));
        } else {
            // tentar retornar estatísticas salvas se não houver sessão ativa
            const userName = Object.keys(usersData).find(u => usersData[u].userId === userId);
            if (userName && usersData[userName]) {
                const stats = usersData[userName].stats || { dailyProfit: 0, wins: 0, losses: 0, tradesToday: 0 };
                const activeFlag = !!usersData[userName].isRunning;
                res.end(JSON.stringify({ active: activeFlag, ...stats }));
            } else {
                res.end(JSON.stringify({ active: false }));
            }
        }
        return;
    }

    // 7. API: Pegar Configuração do Usuário
    if (req.method === 'GET' && req.url.startsWith('/api/user-config')) {
        const urlParts = req.url.split('?');
        const query = new URLSearchParams(urlParts[1]);
        const userId = query.get('userId');
        
        const userName = Object.keys(usersData).find(u => usersData[u].userId === userId);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if(userName) {
            res.end(JSON.stringify(usersData[userName].config || {}));
        } else {
            res.end(JSON.stringify({}));
        }
        return;
    }

    // 8. API: Pegar Logs do Usuário
    if (req.method === 'GET' && req.url.startsWith('/api/logs')) {
        const urlParts = req.url.split('?');
        const query = new URLSearchParams(urlParts[1]);
        const userId = query.get('userId');
        
        const userName = Object.keys(usersData).find(u => usersData[u].userId === userId);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if(userName && usersData[userName].logs) {
            res.end(JSON.stringify({ logs: usersData[userName].logs || [] }));
        } else {
            res.end(JSON.stringify({ logs: [] }));
        }
        return;
    }

    // 9. Servir Arquivos Estáticos (Para todos os arquivos da pasta)
    let filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);
    const extname = String(path.extname(filePath)).toLowerCase();
    const mimeTypes = {
        '.html': 'text/html',
        '.js': 'text/javascript',
        '.css': 'text/css',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
        '.wav': 'audio/wav',
        '.mp4': 'video/mp4',
        '.woff': 'application/font-woff',
        '.ttf': 'application/font-ttf',
        '.eot': 'application/vnd.ms-fontobject',
        '.otf': 'application/font-otf',
        '.wasm': 'application/font-wasm'
    };

    const contentType = mimeTypes[extname] || 'application/octet-stream';

    fs.readFile(filePath, (error, content) => {
        if (error) {
            if(error.code == 'ENOENT') {
                // Fallback para as páginas embutidas se o arquivo não existir
                if (req.url === '/') {
                    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                    res.end(HTML_LOGIN);
                } else if (req.url === '/dashboard') {
                    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                    res.end(HTML_DASHBOARD);
                } else {
                    res.writeHead(404);
                    res.end('Arquivo nao encontrado');
                }
            } else {
                res.writeHead(500);
                res.end('Erro no servidor: '+error.code);
            }
        } else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
});

server.listen(port, () => console.log(`🌍 Painel de Controle: http://localhost:${port}`));

// --- Auto-restore: iniciar bots que estavam rodando antes do restart ---
(function restoreRunningSessions() {
    try {
        Object.keys(usersData).forEach(userName => {
            const u = usersData[userName];
            if (u && u.isRunning && u.config && u.config.token && u.userId) {
                console.log(`🔁 Restaurando sessão para ${userName} (${u.userId})`);
                try {
                    // iniciar em background
                    startBotSession(u.userId, u.config.token, u.config);
                } catch (err) {
                    console.error('Erro ao restaurar sessão:', err && err.message ? err.message : err);
                }
            }
        });
    } catch (e) {
        console.error('Erro na restauração automática de sessões:', e && e.message ? e.message : e);
    }
})();