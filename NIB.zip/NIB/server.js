// simple static file server for the NewInBot project
// run with `node server.js` from the project root

const http = require('http');
const fs = require('fs');
const path = require('path');

// you can either set OPENAI_API_KEY in the environment or
// hard‑code it below for quick testing (not recommended for production).
const OPENAI_API_KEY_FALLBACK = process.env.OPENAI_API_KEY || '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'; // <-- paste your key here if desired

const port = process.env.PORT || 8080;
const rootDir = process.cwd();

const mimeTypes = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2'
};

const server = http.createServer(async (req, res) => {
  let reqPath = req.url.split('?')[0];

  // proxy to OpenAI to avoid CORS and keep key secret
  if (reqPath === '/openai' && req.method === 'POST') {
    // prefer environment, fall back to constant
    const key = process.env.OPENAI_API_KEY || OPENAI_API_KEY_FALLBACK;
    if (!key) {
      const msg = 'OPENAI_API_KEY not set on server. Set OPENAI_API_KEY env var or update OPENAI_API_KEY_FALLBACK in server.js';
      console.error(msg);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: msg }));
      return;
    }

    try {
      let body = '';
      req.on('data', chunk => (body += chunk));
      await new Promise(r => req.on('end', r));
      const apiResp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${key}`
        },
        body
      });
      const data = await apiResp.text();
      res.writeHead(apiResp.status, { 'Content-Type': 'application/json' });
      res.end(data);
    } catch (e) {
      res.writeHead(500);
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }

  if (reqPath === '/') reqPath = '/index.html';

  const filePath = path.join(rootDir, reqPath);

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const contentType = mimeTypes[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
});

server.listen(port, () => {
  console.log(`Static server running at http://localhost:${port}`);
  if (!process.env.OPENAI_API_KEY) {
    console.warn('⚠️  OPENAI_API_KEY environment variable is not defined. ChatGPT features will fail.');
  }
});
