(function(){
  document.addEventListener('DOMContentLoaded', function(){
    // Add touch-friendly pressable class when device supports touch
    try{
      if ('ontouchstart' in window) {
        document.querySelectorAll('.btn').forEach(b => b.classList.add('pressable'));
      }
    }catch(e){/* ignore */}

    const nodes = Array.from(document.querySelectorAll('.fade-in'));
    if (!nodes.length) return;

    if (!('IntersectionObserver' in window)){
      nodes.forEach(n => n.classList.add('in-view'));
      return;
    }

    const io = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    }, {threshold: 0.12});

    nodes.forEach(n => io.observe(n));
  });
})();
